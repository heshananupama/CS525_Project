"""

Application name 	525
API key 	f8371934a58e95be895d9ebaf3e6c32f
Shared secret 	2ddf5cfbbbbcad2934cf3977beb10b45
Registered to 	ehschutzman

"""

import requests
import json


def generate_table_row(artist):
    start = "http://ws.audioscrobbler.com/2.0/?method=artist.gettopalbums&artist="
    end = "&api_key=f8371934a58e95be895d9ebaf3e6c32f&format=json"

    res = requests.request("GET", start + '+'.join(artist.split(' ')) + end)
    j = res.json()['topalbums']

    # print(json.dumps(j, indent=4, sort_keys=True))

    topAlbums = j['album'][:3]

    for a in topAlbums:
        # print(a)
        img = a['image'][1]
        row = '<tr><th>' + artist + '</th><th>' + a['name'] + ' </th> <th><a href=' + a['url'] + ' target="_blank"><img src=' + img[
            '#text'] + '></a> </th></tr>'



    return row

def extract_artists(string):
    artists = []
    for arg in string.split('&'):
        # print(arg)
        artists.append(' '.join(arg.split('=')[1].split('+')))
    print(artists)
    return artists

def reccomender(artists):
    #return list containing top artists
    return artists



from flask import Flask, render_template, request, jsonify, send_from_directory
import os
app = Flask(__name__)
app.config['CORS_HEADERS'] = 'Content-Type'

app = Flask(__name__)

@app.route('/')
def index():
    print()

    return render_template('index.html')

@app.route('/js/<path:path>')
def send_js(path):
    # print("sending js")
    return send_from_directory('js', path)

@app.route('/css/<path:path>')
def send_css(path):
    return send_from_directory('css', path)

@app.route('/dummy/<path:path>')
def send_dummy(path):
    return send_from_directory('dummy', path)
@app.route('/r')
def r():
    name1 = request.args.get('name1')
    name2 = request.args.get('name2')
    name3 = request.args.get('name3')

    artists = [name1, name2, name3]
    print(artists)
    html = ""
    topArtists = reccomender(artists)
    for artist in topArtists:
        html += generate_table_row(artist)

    return jsonify({'html': html})



if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')