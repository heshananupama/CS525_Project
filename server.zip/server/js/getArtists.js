function getArtists(){
        var artist1 = document.getElementById('artist1').value.split(' ').join('+')
        var artist2 = document.getElementById('artist2').value.split(' ').join('+')
        var artist3 = document.getElementById('artist3').value.split(' ').join('+')
        var req = 'name1=' + artist1 + '&name2=' + artist2 + '&name3='+ artist3
        console.log(URL + '/r?'+ req)
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = handle_response;
        xhr.open("GET", '/r?'+req);

        xhr.send();        

    }
    function handle_response(){
      if (this.readyState != 4) return;
        if (this.status != 200) {
            //error
        }
        var data = this.responseText;    
        var json = JSON.parse(data)
        document.getElementById('table-content').innerHTML = json.html
    }